<?php ob_start() ?>
    <table>
        <tr>
            <th>Image</th>
            <th>Titre</th>
            <th>Nombre de pages</th>
            <th>Actions</th>
        </tr>
        <tr>
            <td><img src="public/images/html.jpg" alt=""></td>
            <td>HTML 5</td>
            <td>300</td>
            <td>
                <!-- Divisez la colonne "Actions" en deux sous-colonnes -->
                <button>Modifier</button>
                <button>Supprimer</button>
            </td>
        </tr>
        <tr>
            <td><img src="public/images/css.jpg" alt=""></td>
            <td>CSS 3</td>
            <td>350</td>
            <td>
                <!-- Divisez la colonne "Actions" en deux sous-colonnes -->
                <button>Modifier</button>
                <button>Supprimer</button>
            </td>
        </tr>
        <tr>
            <td><img src="public/images/js.jpg" alt=""></td>
            <td>Le JavaScript</td>
            <td>250</td>
            <td>
                <!-- Divisez la colonne "Actions" en deux sous-colonnes -->
                <button>Modifier</button>
                <button>Supprimer</button>
            </td>
        </tr>
        <tr>
            <td><img src="public/images/php.jpg" alt=""></td>
            <td>PHP 8</td>
            <td>550</td>
            <td>
                <!-- Divisez la colonne "Actions" en deux sous-colonnes -->
                <button>Modifier</button>
                <button>Supprimer</button>
            </td>
        </tr>
    </table>
    <button>Ajouter</button>


<?php 
$titre = "Les livres de la bibliothèque";
$content = ob_get_clean();
require "template.php"; 
?>
